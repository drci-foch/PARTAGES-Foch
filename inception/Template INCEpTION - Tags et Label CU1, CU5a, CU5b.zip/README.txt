Première utilisation du projet 

-> Importer le projet dans Inception

	Importez le projet dans Inception.

	Ouvrez le projet une fois l’import terminé.

-> Configurer les utilisateurs

	Allez dans Settings.

	Ouvrez l’onglet Users.

	Ajoutez-vous en tant qu’annotateur (ou avec tout autre droit nécessaire).

-> Importer un document de test

	Allez dans l’onglet Documents.

	Importez un fichier sur lequel vous souhaitez effectuer des tests.

-> Lancer l’annotation

	Retournez à l’accueil.

	Rouvrez le projet.

	Un nouvel onglet Annotation apparaîtra.

	Tester le template

=> Référez-vous au guide d’annotation dédié pour plus d’explications sur l’utilisation et les règles d’annotation.